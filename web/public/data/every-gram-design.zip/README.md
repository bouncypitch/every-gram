# Every Gram design pack

Berkeley Humanoid Lite parts redesigned in Nylon 12 + CF. Results are simulation only, with typical datasheet properties and assumed load cases. Fatigue, impact, thermal and print behavior are untested. Do not use for safety-critical parts without engineering review.

- yoke: 105.7 g to 43.7 g, peak 11.9/30 MPa, deflection 1.05x, case: 3 x body weight through ankle
- foot: 454.3 g to 171.5 g, peak 15.6/30 MPa, deflection 1.10x, case: 3 x body weight on toe, then on heel
- arm: 130.1 g to 89.0 g, peak 28.8/30 MPa, deflection 0.40x, case: 250 N side load, from 20 N m joint limit at 80 mm
