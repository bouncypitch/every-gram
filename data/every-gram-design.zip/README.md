# Every Gram design pack

Berkeley Humanoid Lite parts redesigned in Nylon 12 + CF. Results are simulation only, with typical datasheet properties and assumed load cases. Fatigue, impact, thermal and print behavior are untested. Do not use for safety-critical parts without engineering review.

- yoke: 105.7 g to 48.5 g, peak 8.3/30 MPa, deflection 0.81x, case: 3 x body weight through ankle
- foot: 449.5 g to 197.3 g, peak 13.0/30 MPa, deflection 0.86x, case: 3 x body weight on toe, then on heel
- arm: 130.1 g to 89.0 g, peak 28.8/30 MPa, deflection 0.40x, case: 250 N side load, from 20 N m joint limit at 80 mm
- hip: 94.2 g to 64.7 g, peak 29.8/30 MPa, deflection 0.47x, case: 3 x body weight axial, 1.5 x side
